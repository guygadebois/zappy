#ifndef __POS_HH__
#define __POS_HH__

class Pos
{
public:
	int x;
	int y;

	Pos() {};
	Pos(int _x, int _y) : x(_x), y(_y) {};
	~Pos() {};
};

#endif