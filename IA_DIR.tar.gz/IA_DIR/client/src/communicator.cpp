#include "IA.hh"
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <utility>

void 				IA::handleAnswer(Task task)
{
	std::string tmp;
	std::string answer;

	tmp = task.getCommandType();
	if (this->_tabActions.find(tmp) == this->_tabActions.end())
	{
		return ;
	}
	answer = task.getAnswer();
	(this->*_tabActions[tmp])(answer);
}

void 				IA::handleAnswerVoir(std::string &val)
{
	this->updateView(this->_parser->parseView(val));
}

void 				IA::handleAnswerPrendre(std::string &val)
{
	if (val == "ok")
	{
		if (this->_isAvailable == true)
			this->_hasToUpdateInventory = true;
	}
	this->_isSearchingSomething = false;

}

void 				IA::handleAnswerPoser(std::string &val)
{
	if (val == "ok")
	{
		if (this->_isAvailable == true || this->_needToTakeFood)
		this->_hasToUpdateInventory = true;
	}
}

void 				IA::handleAnswerInventaire(std::string &val)
{
	std::vector<std::string> tmp;

	tmp = this->_parser->parseInventory(val);
	tmp.push_back(intToString(this->_level));
	tmp.push_back(intToString(this->_isAvailable));

	this->updateInventory(this->_id, tmp);
}

void 				IA::handleAnswerIncantation(std::string &val)
{
	const char *tmp;

	tmp = val.c_str();
	if (tmp[0] && tmp[0] == 'n')
	{
		this->_level++;
		this->_isAvailable = true;
		this->_hasToBroadcastInventory = true;
		this->_canEventuallyEvolve = false;
		this->_isChief = false;
		this->_isAtRightPlace = false;
		this->_needToClearPlace = false;
		this->_group.clear();
	}
}

void 				IA::handleAnswerBroadcast(std::string &val)
{
	if (val == "ok")
	{
		this->_hasToBroadcastInventory = false;
	}
}

void				IA::handleNoAnswer(std::string &val)
{
	(void)val;
}

bool 				IA::needFood(const int nbr)
{
	if ((this->_infos[this->_id].getInventaire())[0] < nbr)
	{
		return (true);
	}
	return (false);
}