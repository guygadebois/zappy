#include "IA.hh"
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <utility>

void		IA::getItemPos(std::string &obj)
{
	int level = 0;
	int dx = 0;
	int dy = 0;

	_direction = FRONT;
	for (unsigned int y = 0 ; y < _view.size() ; ++y)
	{
		for (unsigned int x = 0 ; x < _view[y].size() ; ++x)
		{
			if (_view[y][x] == obj)
			{
				this->_pos->x = dx;
				this->_pos->y = dy;
				return ;
			}
		}
		++dx;
		if (dx > level)
		{
			++level;
			dx = -level;
			++dy;
		}
	}
	this->_pos->x = this->_pos->y = -1;
	return ;
}

bool	IA::goToPos()
{
	if (this->_pos->y > 0) {
		--this->_pos->y;
		_action = "avance";
	}
	else if (this->_pos->x > 0) {
		if (_direction != RIGHT) {
			_action = "droite";
			_direction = RIGHT;
		}
		else {
			--this->_pos->x;
			_action = "avance";
		}
	}
	else if (this->_pos->x < 0) {
		if (_direction != LEFT) {
			_action = "gauche";
			_direction = LEFT;
		}
		else {
			++this->_pos->x;
			_action = "avance";
		}
	}
	else
		return (false);
	return (true);
}

bool	IA::goToCase(int &n)
{
	if (n == 1 || n == 2 || n == 8)
		_action = "avance";
	else if (n >= 3 && n <= 4)
		_action = "gauche";
	else if (n == 5 || n == 6 || n == 7)
		_action = "droite";
	else
		return (false);
	if (n == 5)
		n = 7;
	else if (_action == "droite")
		n -= 2;
	else if (_action == "gauche")
		n += 2;
	if (n > 8)
		n -= 8;
	else if (n < 1)
		n += 8;
	++_timeSinceFollow;
	return (true);
}