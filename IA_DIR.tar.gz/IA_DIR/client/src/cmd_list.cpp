#include <iostream>
#include <unistd.h>
#include "Game.hh"

void Game::avance()
{
	this->_network->addCmd("avance\n");
}

void Game::gauche()
{
	this->_network->addCmd("gauche\n");
}

void Game::droite()
{
	this->_network->addCmd("droite\n");
}

void Game::voir()
{
	this->_network->addCmd("voir\n");
}

void Game::inventaire()
{
	this->_network->addCmd("inventaire\n");
}

void Game::poseObjet()
{
	std::string tmp;

	tmp = this->_IA->getTexte();
	this->_network->addCmd(tmp);
}

void Game::prendObjet()
{
	std::string tmp;

	tmp = this->_IA->getTexte();
	this->_network->addCmd(tmp);
}

void Game::expulse()
{
	this->_network->addCmd("expulse\n");
}

void Game::broadcast()
{
	std::string tmp;

	tmp = this->_IA->getTexte();
	tmp += "\n";
	this->_network->addCmd(tmp);
}

void Game::incantation()
{
	this->_network->addCmd("incantation\n");
}

void Game::fork()
{
	this->_network->addCmd("fork\n");
}

void Game::endGame()
{
	this->_isRunning = false;
}
