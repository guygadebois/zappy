#include "IA.hh"
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <utility>

void 				IA::hasReceivedBroad()
{
	this->_hasReceivedBroad = true;
}

void 				IA::setBroad(Broadcast *val)
{
	if (!val)
	{
		return ;
	}
	this->_hasReceivedBroad = true;
	this->_broad = val;
	this->handleBroadcast();
}

void 				IA::handleBroadcast()
{
	(this->*_tabBroadcast[this->_broad->getType()])();
}

void  IA::constructBroadcastInventaire(std::string &inventaire)
{
	this->_message = "broadcast " + randString() + "-" + this->_team + "-" + this->_id + "-" + "ALL" + "-" + "inventaire" + "-" + inventaire;
}

void  IA::constructBroadcastDeplacement(std::string &dest)
{
	this->_message = "broadcast " + randString() + "-" + this->_team + "-" + this->_id + "-" + dest + "-" + "deplacement" + "-" + "EMPTY";
}

void IA::constructBroadcastDead()
{
	this->_message = "broadcast " + randString() + "-" + this->_team + "-" + this->_id + "-" + "ALL" + "-" + "dead" + "-" + "EMPTY";
}

void IA::constructBroadcastCasse(std::string &dest)
{
	this->_message = "broadcast " + randString() + "-" + this->_team + "-" + this->_id + "-" + dest + "-" + "casse" + "-" + "EMPTY";
}

void IA::handleBroadcastInventaire()
{
	std::string val("");

	val = this->_broad->getData();
	this->updateInventory(this->_broad->getFrom(), this->_parser->parseInventory(val));
}

void IA::handleBroadcastCasse()
{
	this->_isAvailable = true;
	this->_hasToBroadcastInventory = true;
	this->_canEventuallyEvolve = false;
	this->_isChief = false;
	this->_isAtRightPlace = false;
	this->_needToClearPlace = false;
	this->_group.clear();
}

void IA::handleBroadcastDead()
{
	std::string tmp = this->_broad->getFrom();
	this->_infos.erase(tmp);
	if (tmp == this->_chief)
	{
		this->handleBroadcastCasse();
		return ;
	}
	if (this->_isChief && this->belongToGroup(tmp))
	{
		this->casseGroup();
		return ;
	}

}

void IA::handleBroadcastDeplacement()
{
	std::string val("");

	_timeSinceFollow = 0;
	val = this->_broad->getData();
	_rejoinCase = this->_broad->getCase();
	if (this->_isAvailable == true)
		this->_hasToBroadcastInventory = true;
	if (this->_isChief == false)
		this->_isAvailable = false;
	this->_chief = this->_broad->getFrom();
}

bool				IA::belongToGroup(const std::string &val)
{
	for (std::vector<std::string>::iterator it = this->_group.begin() ; it != this->_group.end() ; ++it)
	{
		if ((*it) != this->_id && (*it) == val)
			return (true);
	}
	return (false);
}

const std::string &IA::getTexte() const
{
	return (this->_message);
}

const std::string &IA::getTeam() const
{
	return (this->_team);
}
