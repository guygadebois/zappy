#include  <iostream>
#include "Network.hh"
#include "Game.hh"
#include "tools.hh"

void  handle_game(const std::string &ip, const int port, const std::string &team)
{
	printf("At the very beginnig\n");
  std::string id(intToString(time(NULL)  + getpid() + rand() % 424242));
	printf("At the begining\n");
  Network *network = new Network(ip, port, id);
  printf("After da network\n");
  Game *game = new Game(network, team);
  printf("AFTER DA GAME !\n");
  printf("In da handle Game, bitch\n");
  if (game->connection())
  {
    printf("In da if\n");
	  game->launch(id);
  }
	else
    {
		printf("In da else\n");
      std::cout << "Connexion failed !" << std::endl;
      return ;
    }
}

bool		check_arguments(char **av, int args)
{
  std::string	tmp;
  std::string	sip("127.0.0.1");
  int		ip;
  int		port;
  int		name;
  int		i = 1;
	
  printf("Hello motherfucker\n");
  while (i < args)
    {
      if (i % 2 != 0)
	{
	  tmp = av[i];
	  if (tmp == "-n")
	    name = i + 1;
	  else if (tmp == "-h")
	    ip = i + 1;
	  else if (tmp == "-p")
	    port = i + 1;
	  else
	    return (true);
	}
      i++;
    }
  printf("You little Bitch\n");
  if (args == 7)
  {
	  printf("if\n");
    handle_game(av[ip], atoi(av[port]), av[name]);
  	printf("if say whaaat\n");
  }
	else
	{
		printf("port = %d name = %d\n", port, name);
		printf("else \n");
		handle_game(sip, atoi(av[port]), av[name]);
	printf("else say whaaaaat\n");
	}
		return (false);
}

int main(int ac, char **av)
{
  srand((time(NULL) + getpid()));
  if (check_arguments(av, ac) == true)
    {
      std::cout << "Usage: " << av[0] << " -n team -h ip -p port" << std::endl;
      return (1);
    }
  return (0);
}
