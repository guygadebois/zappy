#include "IA.hh"
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <utility>

void				IA::init(const std::string &id)
{
	this->_parser = new Parse();
	this->_broad = new Broadcast();
	this->initView();
	this->_id = id;
	this->initTabFunc();
	this->initCorrespondance();
	this->_pos = new Pos(-1, -1);
}

void				IA::initCorrespondance()
{
	this->_correspondanceStringInt["nourriture"] = 0;
	this->_correspondanceStringInt["linemate"] = 1;
	this->_correspondanceStringInt["deraumere"] = 2;
	this->_correspondanceStringInt["sibur"] = 3;
	this->_correspondanceStringInt["mendiane"] = 4;
	this->_correspondanceStringInt["phiras"] = 5;
	this->_correspondanceStringInt["thystame"] = 6;

	this->_correspondanceIntString[0] = "nourriture";
	this->_correspondanceIntString[1] = "linemate";
	this->_correspondanceIntString[2] = "deraumere";
	this->_correspondanceIntString[3] = "sibur";
	this->_correspondanceIntString[4] = "mendiane";
	this->_correspondanceIntString[5] = "phiras";
	this->_correspondanceIntString[6] = "thystame";
}

void 				IA::initTabFunc()
{
	this->_tabActions["avance"] = &IA::handleNoAnswer;
	this->_tabActions["droite"] = &IA::handleNoAnswer;
	this->_tabActions["gauche"] = &IA::handleNoAnswer;
	this->_tabActions["voir"] = &IA::handleAnswerVoir;
	this->_tabActions["inventaire"] = &IA::handleAnswerInventaire;
	this->_tabActions["prend"] = &IA::handleAnswerPrendre;
	this->_tabActions["incantation"] = &IA::handleAnswerIncantation;
	this->_tabActions["pose"] = &IA::handleAnswerPoser;
	this->_tabActions["broadcast"] = &IA::handleAnswerBroadcast;
	this->_tabBroadcast["inventaire"] = &IA::handleBroadcastInventaire;
	this->_tabBroadcast["deplacement"] = &IA::handleBroadcastDeplacement;
	this->_tabBroadcast["casse"] = &IA::handleBroadcastCasse;
	this->_tabBroadcast["dead"] = &IA::handleBroadcastDead;
	// this->_tabActions["fork"] = &Game::fork;
}

void 				IA::initView()
{
	std::vector<std::string> tmpTab;
	std::string 			 tmpString("");

	tmpTab.push_back(tmpString);
	for (int i = 0 ; i < 81 ; i++)
	{
		this->_view.push_back(tmpTab);
	}
}