#include "IA.hh"
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <utility>

void 			IA::findObject(std::string &val)
{
	this->getItemPos(val);
	if (this->_pos->y == -1 && this->_pos->y == -1)
	{
		this->_action = "avance";
	}
	else
	{
		this->_isSearchingSomething = true;
	}
}

void 				IA::moveToObject()
{
	if (!this->goToPos())
	{
		this->_canTakeObj = true;
	}
}

std::string 		&IA::takeObj(const std::string &obj)
{
	this->_action = "prendObjet";
	this->_message = "prend " + obj + "\n";
	this->_canTakeObj = false;
	return (this->_action);
}

void 				IA::poseObj(const std::string &obj)
{
	this->_action = "poseObjet";
	this->_message = "pose " + obj + "\n";
	this->_canTakeObj = false;
}

void 				IA::chooseObjectForLevel(int level)
{
	std::vector<int> tmp;
	unsigned int a = 0;

	tmp = this->_infos[this->_id].getInventaire();
	for (std::vector<int>::iterator it = this->_levelDef[level].begin() ; it != this->_levelDef[level].end() ; ++it)
	{
		if ((*it) != 0)
		{
			if (a < tmp.size() && tmp[a] < (*it))
			{
				this->_objetToFind = this->_correspondanceIntString[a];
				return ;
			}
		}
		a++;
	}
	this->_hasEnoughItemsForLevel = true;
	this->_objetToFind = "nourriture";
}
