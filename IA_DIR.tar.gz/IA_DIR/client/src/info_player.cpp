#include "IA.hh"
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <utility>

void IA::updateView(std::vector<std::vector<std::string> > &val)
{
	if (val.size() > this->_view.size())
		return ;
	std::vector<std::vector<std::string> >::iterator it, it2;

	it = val.begin();
	it2 = this->_view.begin();
	for( ; it != val.end() && it2 != this->_view.end(); it++, it2++)
	{
		(*it2).clear();
		(*it2) = (*it);
	}
}

void IA::updateInventory(const std::string &id, std::vector<std::string> stock)
{
	_infos[id].setInventaire(stock);

	_infos[id].setId(id);


	this->tryToSocialize();
}