#ifndef		__MAIN_HH__
# define	__MAIN_HH__

#include	<iostream>

#define		W_WIDTH		1280
#define		W_HEIGHT	720
#define		ZOOM_LEVEL	4
#define		MOVE_BY		25
#define		NB_FUNC		25

enum Type
{
	INVENTAIRE,
	DEPLACEMENT,
	POSER,
	INCANTE,
	DEAD,
	EMPTY
};

enum Status
{
	COMPOSING,
	COMPLETED,
	TOGETHER
};

#define			NORMAL_FOOD 15 
#define			URGENCE_FOOD 5

#endif

