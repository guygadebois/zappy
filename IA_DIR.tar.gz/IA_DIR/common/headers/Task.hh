#ifndef			__TASK_HH__
#define			__TASK_HH__

#include		<string>

class			Task
{
private:
  std::string		_commandType;
  std::string		_answer;
public:
  Task();
  ~Task();
  /***/
  std::string		getCommandType() const;
  std::string		getAnswer() const;
  void			    setCommandType(const std::string &commandType);
  void			    setAnswer(const std::string &answer);
  /****/
};

#endif
